package com.example.divya.button;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button4,button5,button6;
    Toast toast;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button4 =(Button)findViewById(R.id.button4);
        button5=(Button)findViewById(R.id.button5);
        button6=(Button)findViewById(R.id.button6);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast.makeText(MainActivity.this,"Toast for Activity",toast.LENGTH_SHORT).show();
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ns=Context.NOTIFICATION_SERVICE;
                Intent notificationIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com"));

                PendingIntent contentIntent=PendingIntent.getActivity(MainActivity.this,0,notificationIntent,0);

                NotificationManager notificationManager=(NotificationManager)getSystemService(ns);

                Notification notification=new Notification.Builder(MainActivity.this)
                        .setTicker("MESSAGE")
                        .setContentTitle("NEW MESSAGE")
                        .setContentText("hello!you have a new message")
                        .setSmallIcon(R.drawable.notification)
                        .setContentIntent(contentIntent).getNotification();
                notification .flags=Notification.FLAG_AUTO_CANCEL;
                notificationManager.notify(0,notification);
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog dialog=new AlertDialog.Builder(MainActivity.this).create();
                dialog.setTitle("DIALOG BOX");
                dialog.setMessage("This is the dialog box");
                dialog.show();
            }
        });




    }
}
